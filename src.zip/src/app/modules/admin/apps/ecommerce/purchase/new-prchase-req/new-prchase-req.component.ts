import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-new-prchase-req',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './new-prchase-req.component.html',
  styleUrl: './new-prchase-req.component.scss'
})
export class NewPrchaseReqComponent {

}
