import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-up-or-add-emp',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './up-or-add-emp.component.html',
  styleUrl: './up-or-add-emp.component.scss'
})
export class UpOrAddEmpComponent {

}
