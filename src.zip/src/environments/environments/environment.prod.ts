export const environment = {
  version: "0.0.1",
  production: true,
  apiURL: "http://3.28.120.132:5208",
  clientid:"ERPWebApp"
};
